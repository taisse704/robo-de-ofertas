const SOURCE = "robo-de-ofertas";
const LINKS_ENDPOINT = "/affiliate-program/api/v2/stripe/user/links";
const TAGS_ENDPOINT = "/affiliate-program/api/v2/stripe/user/tags";
const TAG_CACHE_MS = 5 * 60 * 1000;
const FETCH_TIMEOUT_MS = 12000;

async function requisicaoComTimeout(url, options = {}) {
  const controller = new AbortController();
  let timer;

  try {
    const operacao = (async () => {
      const response = await fetch(url, { ...options, signal: controller.signal });
      const text = await response.text();
      return { response, text };
    })();

    const limite = new Promise((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        reject(new Error("O Mercado Livre demorou mais de 12 segundos para responder, incluindo a leitura da resposta. Verifique se a conta está conectada e tente novamente."));
      }, FETCH_TIMEOUT_MS);
    });

    return await Promise.race([operacao, limite]);
  } catch (error) {
    if (controller.signal.aborted && !String(error?.message || "").includes("12 segundos")) {
      throw new Error("A solicitação ao Mercado Livre foi interrompida após o limite de 12 segundos.");
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

let tagCache = "";
let tagCacheAt = 0;

function enviarResultado(offerId, data = {}) {
  chrome.runtime.sendMessage({
    type: "ML_AFFILIATE_RESULT",
    offer_id: offerId || null,
    ...data
  });
}

function normalizarUrlProduto(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";

  try {
    const u = new URL(raw);
    u.hash = "";
    return u.toString();
  } catch {
    return raw;
  }
}

function interpretarResposta(text) {
  let json = {};

  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {};
  }

  return { json, text };
}

async function obterTagAtiva() {
  const agora = Date.now();

  if (tagCache && agora - tagCacheAt < TAG_CACHE_MS) {
    return tagCache;
  }

  const tagRequest = await requisicaoComTimeout(TAGS_ENDPOINT, {
    method: "GET",
    headers: {
      Accept: "application/json, text/plain, */*"
    },
    credentials: "include",
    cache: "no-store"
  });

  const tagResponse = tagRequest.response;
  const tagResult = interpretarResposta(tagRequest.text);
  const tagData = tagResult.json;

  if (!tagResponse.ok) {
    throw new Error(
      "Mercado Livre recusou a consulta das etiquetas: HTTP " +
      tagResponse.status +
      (tagData?.message ? " - " + tagData.message : "")
    );
  }

  const tags = Array.isArray(tagData)
    ? tagData
    : Array.isArray(tagData?.tags)
      ? tagData.tags
      : Array.isArray(tagData?.data)
        ? tagData.data
        : [];

  const active =
    tags.find((item) => item?.in_use === true) ||
    tags.find((item) => item?.inUse === true) ||
    tags.find((item) =>
      String(item?.status || "").toLowerCase() === "active"
    ) ||
    null;

  const tag = String(
    active?.tag ||
    active?.id ||
    active?.name ||
    ""
  ).trim();

  if (!tag) {
    throw new Error(
      "O Mercado Livre não informou uma etiqueta de afiliado ativa. " +
      "Quantidade de etiquetas retornadas: " + tags.length + "."
    );
  }

  tagCache = tag;
  tagCacheAt = agora;

  return tag;
}

chrome.runtime.sendMessage({
  type: "ML_AFFILIATE_READY"
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== "ML_AFFILIATE_GENERATE_ON_TAB") {
    return;
  }

  (async () => {
    const offer = message.offer || {};
    const offerId = String(offer.offer_id || "").trim();
    const productUrl = normalizarUrlProduto(offer.product_url);

    if (!offerId || !productUrl) {
      enviarResultado(offerId, {
        ok: false,
        error: "Oferta sem ID ou URL do produto."
      });
      return;
    }

    try {
      // Não navegamos até o produto a cada oferta.
      // O endpoint oficial aceita a URL do produto diretamente,
      // então mantemos a mesma aba autenticada do Mercado Livre.
      const tag = await obterTagAtiva();

      const linkRequest = await requisicaoComTimeout(LINKS_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json, text/plain, */*"
        },
        credentials: "include",
        cache: "no-store",
        body: JSON.stringify({
          url: productUrl,
          tag
        })
      });

      const linkResponse = linkRequest.response;
      const linkResult = interpretarResposta(linkRequest.text);
      const linkData = linkResult.json;

      if (!linkResponse.ok) {
        const detail =
          linkData?.message ||
          linkData?.error ||
          linkData?.errors?.[0]?.message ||
          "";

        throw new Error(
          "Mercado Livre recusou a geração do link: HTTP " +
          linkResponse.status +
          (detail ? " - " + detail : "")
        );
      }

      const affiliateUrl = String(
        linkData?.short_url ||
        linkData?.shortUrl ||
        linkData?.affiliate_url ||
        linkData?.affiliateUrl ||
        ""
      ).trim();

      if (!affiliateUrl) {
        throw new Error(
          "O Mercado Livre respondeu HTTP 200, mas não retornou short_url. " +
          "Resposta: " + linkResult.text.slice(0, 500)
        );
      }

      let hostname = "";

      try {
        hostname = new URL(affiliateUrl).hostname.toLowerCase();
      } catch {}

      const oficial =
        hostname === "meli.la" ||
        hostname === "mercadolivre.com.br" ||
        hostname.endsWith(".mercadolivre.com.br") ||
        hostname === "mercadolivre.com" ||
        hostname.endsWith(".mercadolivre.com");

      if (!oficial) {
        throw new Error(
          "O Mercado Livre retornou um link que não foi reconhecido como oficial: " +
          affiliateUrl
        );
      }

      enviarResultado(offerId, {
        ok: true,
        affiliate_url: affiliateUrl,
        details: {
          id: linkData?.id || null,
          tag: linkData?.tag || tag,
          origin_url: linkData?.origin_url || productUrl
        }
      });
    } catch (error) {
      enviarResultado(offerId, {
        ok: false,
        error: String(error?.message || error)
      });
    }
  })();
});
