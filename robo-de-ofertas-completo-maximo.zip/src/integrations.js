// Provider integration registry. Only official/authorized APIs are allowed.
export const AFFILIATE_PROVIDERS = [
  { key: 'shopee', name: 'Shopee', mode: 'affiliate', status: 'requires_official_access', note: 'A conversão automática só deve usar uma API/endpoint oficial disponibilizado à sua conta de afiliada.' },
  { key: 'mercadolivre', name: 'Mercado Livre', mode: 'affiliate', status: 'requires_official_access', note: 'O Portal do Afiliado possui o Gerador de Links; a API pública não deve ser tratada como gerador de links sem documentação específica.' },
  { key: 'magalu', name: 'Magalu', mode: 'affiliate', status: 'requires_official_access', note: 'As APIs públicas do Magalu usam OAuth2; o acesso de afiliado/influenciador precisa ser autorizado pelo programa correspondente.' },
  { key: 'amazon', name: 'Amazon', mode: 'affiliate', status: 'requires_official_access', note: 'Creators API/PA-API exigem conta de Associado aceita e credenciais/aprovação conforme o programa.' }
];

export function getProvider(key) {
  return AFFILIATE_PROVIDERS.find((p) => p.key === key) || null;
}
