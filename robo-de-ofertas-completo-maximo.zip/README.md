# robo-de-ofertas
## Integrações de afiliadas

O projeto agora possui uma camada de integração separada para Shopee, Mercado Livre, Magalu e Amazon.

Importante: o robô não faz login automatizado com senha nem scraping. A conversão de links e acesso a dados deve usar somente APIs/fluxos oficialmente autorizados pela respectiva plataforma.

- Shopee: a Shopee exige links de afiliado gerados pela própria plataforma; acesso automático depende de uma API/endpoint oficial disponibilizado à conta.
- Mercado Livre: o Portal do Afiliado oferece Gerador de Links; a API pública do Mercado Livre não deve ser tratada como gerador de links sem documentação específica.
- Magalu: as APIs públicas usam OAuth2; o programa de afiliados/influenciador precisa autorizar o fluxo correspondente.
- Amazon: Creators API/PA-API exige conta de Associado aceita e credenciais/aprovação.

Credenciais privadas devem ser configuradas nos Secrets do Supabase, nunca no frontend ou no banco.

## Implementação avançada

Esta versão inclui uma fila de automação (`automation_jobs`), processamento de tarefas (`process-jobs`), geração de conteúdo (`generate-content`) e um worker que inicia ciclos automáticos (`robot-worker`).

### Amazon
O conector usa a Creators API oficial e lê as credenciais exclusivamente dos Secrets do Supabase:
- `AMAZON_CREDENTIAL_ID`
- `AMAZON_CREDENTIAL_SECRET`
- `AMAZON_PARTNER_TAG`
- opcional: `AMAZON_SEARCH_KEYWORDS`

A documentação oficial da Amazon exige conta de Associado aceita e acesso à Creators API; o Partner Tag é usado para atribuição. Não altere links devolvidos pela API.

### Shopee, Mercado Livre e Magalu
O projeto não implementa scraping, automação de navegador ou login por senha. Essas plataformas ficam com estado `aguardando_autorizacao` até que exista um endpoint/API oficial de afiliado autorizado para a conta. O worker não inventa um endpoint nem converte links por método não documentado.

### Publicação
A função `publish-content` é a fronteira de publicação. Ela só permite canais configurados como conectados e foi preparada para receber tokens/permissões oficiais. Não há armazenamento de senha de redes sociais.

### Fluxo
1. contas afiliadas ativas entram na fila;
2. conectores oficiais buscam ofertas;
3. ofertas são gravadas;
4. conteúdo é gerado automaticamente;
5. publicação só ocorre quando o canal tiver autorização oficial;
6. erros ficam registrados na fila/logs.
