-- Automação do Robô de Ofertas. Seguro para executar mais de uma vez.
create extension if not exists pgcrypto;

create table if not exists public.automation_jobs (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  tipo text not null, plataforma text, status text not null default 'pendente', tentativas int not null default 0,
  proxima_execucao timestamptz default now(), executado_em timestamptz, erro text, dados jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists automation_jobs_due on public.automation_jobs(status, proxima_execucao);
alter table public.automation_jobs enable row level security;
drop policy if exists automation_jobs_owner on public.automation_jobs;
create policy automation_jobs_owner on public.automation_jobs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

alter table public.settings add column if not exists exigir_aprovacao boolean default false;
alter table public.settings add column if not exists intervalo_minutos integer default 30;
alter table public.settings add column if not exists canais jsonb not null default '{}'::jsonb;

alter table public.affiliate_accounts add column if not exists status text default 'aguardando_autorizacao';
alter table public.affiliate_accounts add column if not exists nome_conta text;
alter table public.affiliate_accounts add column if not exists configuracao jsonb not null default '{}'::jsonb;
alter table public.affiliate_accounts add column if not exists ultimo_sync timestamptz;

create table if not exists public.generated_contents (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  offer_id uuid references public.offers(id) on delete set null, tipo text not null default 'oferta',
  titulo text, legenda text, roteiro text, hashtags text[], status text not null default 'rascunho',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.generated_contents enable row level security;
drop policy if exists generated_contents_owner on public.generated_contents;
create policy generated_contents_owner on public.generated_contents for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.channel_accounts (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  canal text not null, status text not null default 'aguardando_autorizacao', configuracao jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(user_id, canal)
);
alter table public.channel_accounts enable row level security;
drop policy if exists channel_accounts_owner on public.channel_accounts;
create policy channel_accounts_owner on public.channel_accounts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists generated_contents_user on public.generated_contents(user_id, created_at desc);
create index if not exists channel_accounts_user on public.channel_accounts(user_id, canal);
