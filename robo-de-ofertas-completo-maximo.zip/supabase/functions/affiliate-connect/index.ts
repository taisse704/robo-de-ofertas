// OAuth callback boundary. Provider-specific OAuth implementations must be added
// using the official API of each affiliate network. Never store passwords here.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, content-type' } });
  const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('Authorization') || '' } } });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return new Response('Não autenticado', { status: 401 });
  return new Response(JSON.stringify({ ok: true, message: 'Endpoint de conexão pronto. Configure o OAuth oficial do provedor.' }), { headers: { 'Content-Type': 'application/json' } });
});
