// Publicação é feita somente por APIs oficiais autorizadas. Não usa login/senha nem scraping.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, content-type' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const auth=req.headers.get('Authorization'); if(!auth) throw new Error('Não autenticado.');
    const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth}}});
    const {data:{user}}=await supabase.auth.getUser(); if(!user) throw new Error('Sessão inválida.');
    const body=await req.json(); const canal=String(body.canal||'').toLowerCase();
    const supported=['instagram','tiktok','kwai','whatsapp'];
    if(!supported.includes(canal)) throw new Error('Canal não suportado.');
    const {data:account}=await supabase.from('channel_accounts').select('*').eq('user_id',user.id).eq('canal',canal).maybeSingle();
    if(!account || account.status!=='conectado') throw new Error(`Conecte o ${canal} por uma API oficial antes de publicar.`);
    throw new Error(`Publicação automática no ${canal} requer as credenciais/permissões oficiais desse canal. O conector não fará login por senha.`);
  }catch(e){return new Response(JSON.stringify({ok:false,error:e instanceof Error?e.message:String(e)}),{status:400,headers:{...cors,'Content-Type':'application/json'}})}
});
