import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('Não autenticado.');
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Sessão inválida.');

    const { data: settings } = await supabase.from('settings').select('*').eq('user_id', user.id).maybeSingle();
    if (!settings?.robo_ativo || settings.modo_automacao !== 'automatico') return json({ ok: true, status: 'pausado' });

    const { data: accounts, error: accountsError } = await supabase.from('affiliate_accounts').select('*, platforms(nome)').eq('user_id', user.id).eq('ativo', true);
    if (accountsError) throw accountsError;

    const now = new Date().toISOString();
    const jobs = (accounts || []).map((a: any) => ({ user_id: user.id, tipo: 'buscar_ofertas', plataforma: a.platforms?.nome || 'desconhecida', status: 'pendente', proxima_execucao: now, dados: { account_id: a.id, provider: a.configuracao?.provider || null } }));
    if (jobs.length) {
      const { error } = await supabase.from('automation_jobs').insert(jobs);
      if (error) throw error;
    }
    await supabase.from('logs').insert({ user_id: user.id, tipo: 'robo', nivel: 'sucesso', message: `Ciclo automático enfileirado: ${jobs.length} fonte(s).` });
    return json({ ok: true, status: 'executando', fontes: jobs.length });
  } catch (e) {
    return json({ ok: false, error: e instanceof Error ? e.message : String(e) }, 400);
  }
});

function json(body: unknown, status = 200) { return new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } }); }
