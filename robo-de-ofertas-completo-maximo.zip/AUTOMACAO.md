# Robô de Ofertas — modo automático

O projeto foi preparado para operar em ciclos automáticos: buscar fontes, filtrar ofertas, criar link rastreável, gerar conteúdo, publicar e registrar resultados.

## O que você configura uma vez
- Contas de afiliado.
- Destinos de publicação.
- Regras: desconto/comissão/preço/categorias/limite diário/horário.
- Botão Robô ATIVO/PAUSADO.

## Importante
Os conectores externos precisam usar as APIs oficiais e as permissões disponíveis para cada conta. O projeto não usa senha de rede social nem tenta contornar bloqueios. A conexão de cada provedor é isolada para poder ser ativada quando as credenciais/API correspondentes estiverem disponíveis.

## Worker
`supabase/functions/robot-worker` cria ciclos de trabalho para as contas ativas. Publique a Edge Function e agende sua execução no Supabase.

## Próximo passo técnico
Implementar cada conector oficial com as credenciais do usuário/provedor e ligar o agendamento do worker. Sem essas credenciais, nenhum software consegue publicar de verdade em contas externas.
