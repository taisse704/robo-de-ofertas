# Robô de Ofertas — projeto consolidado V1

Aplicação React + Vite + Supabase para operação assistida de ofertas.

## Fluxo
Oferta → Comparação → Link → Vídeo → Legenda → Revisão → Publicação → Resultados

## Plataformas previstas
Instagram, Kwai, Magalu, Mercado Livre, Shopee, TikTok, TikTok Shop, WhatsApp e YouTube.

## Características
- Login por Supabase Auth
- Dados isolados por `user_id`
- Botão para pausar/continuar o robô
- Cadastro e classificação de ofertas
- Comparação de ofertas
- Criação assistida de conteúdo
- Revisão antes da divulgação
- Preparação de publicações por plataforma
- Resultados básicos
- Área de conexões para conectores independentes
- Configurações por usuário

## Configuração
1. Copie `.env.example` para `.env.local`.
2. Preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY`.
3. `npm install`
4. `npm run dev`

## Importante
A integração real com APIs de marketplaces e redes sociais depende das credenciais, permissões e endpoints de cada plataforma. A V1 mantém os conectores separados para não misturar essas credenciais com a interface.

O arquivo `supabase/supabase_schema.sql` é somente backup da estrutura. Ele não é um dump dos dados.
