# Supabase

`supabase_schema.sql` é o backup da estrutura copiada do projeto. Ele não contém os registros nem os usuários do Auth.

Antes de executar qualquer SQL em um projeto existente, faça backup dos dados e confira as políticas RLS.
